package Assignment_4;
import static org.junit.Assert.*;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class CourseDBManager_STUDENT_Test {
	    private CourseDBManagerInterface dataMgr = new CourseDBManager();
	    /**
	     * Create an instance of CourseDBManager
	     * @throws Exception
	     */
	    @Before
	    public void setUp() throws Exception {
	        dataMgr = new CourseDBManager();
	    }
	    /**
		 * Set dataMgr reference to null
		 * @throws Exception
		 */
		@After
		public void tearDown() throws Exception {
			dataMgr = null;
		}
		/**
		 * Test add method
		 */
	    @Test
	    public void testAddToDB() {
	        try {
	            dataMgr.add("CMSC203", 30504, 4, "SC450", "Joey Bag-O-Donuts");
	        } catch (Exception e) {
	            fail("Should not have thrown an exception");
	        }
	    }
	    /**
	     * test read method
	     */
	    @Test
	    public void testRead() {
	        try {
	            File inputFile = new File("Test1.txt");
	            PrintWriter inFile = new PrintWriter(inputFile);
	            inFile.println("CMSC203 30504 4 SC450 Joey Bag-O-Donuts");
	            inFile.print("CMSC204 30503 4 SC450 Jill B. Who-Dunit");
	            inFile.close();

	            dataMgr.readFile(inputFile);
	            assertEquals("CMSC203", dataMgr.get(30504).getID());
	            assertEquals("CMSC204", dataMgr.get(30503).getID());
	            assertEquals("SC450", dataMgr.get(30503).getRoomNum());
	        } catch (Exception e) {
	            fail("Should not have thrown an exception");
	        }
	    }
	    @Test
		public void testShowAll() {
			dataMgr.add("CMSC201",20501,4,"SC450","Monshi");
			dataMgr.add("CMSC207",10505,4,"SC450","Sandro");
			ArrayList<String> list = dataMgr.showAll();
			assertEquals(list.get(0),"\nCourse:CMSC207 CRN:10505 Credits:4 Instructor:Sandro Room:SC450");
		 	assertEquals(list.get(1),"\nCourse:CMSC201 CRN:20501 Credits:4 Instructor:Monshi Room:SC450");
	    }
}
