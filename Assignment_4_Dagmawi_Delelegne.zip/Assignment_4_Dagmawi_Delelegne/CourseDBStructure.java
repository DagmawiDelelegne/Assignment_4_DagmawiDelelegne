package Assignment_4;

import java.util.ArrayList;
import java.util.LinkedList;
import java.io.FileNotFoundException;
import java.io.IOException;

public class CourseDBStructure implements CourseDBStructureInterface{
	
	public LinkedList<CourseDBElement>[] hashTable;
	int index = 0;
	public CourseDBStructure(int size) 
	{
		// Calculate the size of the hash table based on the provided size and load factor
        int tableSize = (int) (size / 1.5);
        tableSize = next4KPlus3Prime(tableSize);

        // Initialize the hash table with linked lists
        hashTable = new LinkedList[tableSize];
        for (int i = 0; i < tableSize; i++) {
            hashTable[i] = new LinkedList<CourseDBElement>();
        }
	}
	
	public CourseDBStructure(String randomstringthatdoesntdoanything, int i) 
	{
		hashTable = new LinkedList[i];
		for (int j = 0; j < i; j++) 
		{
			hashTable[j] = new LinkedList<CourseDBElement>();
		}
	}
	
	//Adds an element
	@Override
	public void add(CourseDBElement element) {
		// TODO Auto-generated method stub
		try {
			element.hashcode =String.valueOf(element.getCRN()).hashCode();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 index = element.hashCode() % hashTable.length;
		
		 if (hashTable[index].peek() == null || hashTable[index].peek().compareTo(element) != 0) {
		        hashTable[index].add(element);
		    }
	}

	//Retrieves an element
	@Override
	public CourseDBElement get(int crn)throws IOException {
	   
	    for (CourseDBElement cde : hashTable[index]) {
	        if (cde.getCRN() == crn) {
	            return cde;
	        }
	    }
	   throw new IOException(); 
	   
	   }

 
	//Returns size
	@Override
	public int getTableSize() {
		return hashTable.length;
	}
	
	@Override
	public ArrayList<String> showAll() {
		ArrayList<String> courseStrings = new ArrayList<>();
	    for (LinkedList<CourseDBElement> bucket : hashTable) {
	        if (bucket != null) {
	            for (CourseDBElement element : bucket) {
	                courseStrings.add(element.toString());
	            }
	        }
	    }
	    return courseStrings;
		
	}
	private int next4KPlus3Prime(int n) {
		if (n % 2 == 0) {
            n++;
        }
        while (!isPrime(n)) {
            n += 2;
        }
        while (true) {
            if (isPrime(n) && (n - 3) % 4 == 0) {
                return n;
            }
            n += 2; // Move to the next odd number.
        }
       
    }
	
	private boolean isPrime(int num) {
        if (num <= 1) {
            return false;
        }
        if (num <= 3) {
            return true;
        }
        if (num % 2 == 0 || num % 3 == 0) {
            return false;
        }
        int i = 5;
        while (i * i <= num) {
            if (num % i == 0 || num % (i + 2) == 0) {
                return false;
            }
            i += 6;
        }
        return true;
    }
	
}
 
