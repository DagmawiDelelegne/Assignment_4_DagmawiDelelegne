package Assignment_4;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;

public class CourseDBManager implements CourseDBManagerInterface {
    private CourseDBStructure courseDB;

    public CourseDBManager() {
        // Initialize the courseDB with a default size (you can adjust it as needed)
        courseDB = new CourseDBStructure(20);
    }

    @Override
    public void add(String id, int crn, int credits, String roomNum, String instructor) {
        CourseDBElement course = new CourseDBElement(id, crn, credits, roomNum, instructor);
        courseDB.add(course);
    }

    @Override
    public CourseDBElement get(int crn) {
    	
    	try {
    		for (LinkedList<CourseDBElement> bucket : courseDB.hashTable) {
    	        for (CourseDBElement cde : bucket) {
    	            if (cde.getCRN() == crn) {
    	                return cde;
    	            }
    	        }
    	    }
    		/*for (CourseDBElement cde : courseDB.hashTable[courseDB.index]) {
    			System.out.println(crn);
    	        if (cde.getCRN() == crn) {
    	            return cde;
    	        }
    	    }*/
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
    	
    }

    public void readFile(File input) throws FileNotFoundException {
        try {
            Scanner sc = new Scanner(input);
            
            int crn, credits;
            
            CourseDBElement cde;
            
            String c;
            String[] cs;
            while (sc.hasNextLine()) {
                c = sc.nextLine();
                
                cs = c.split(" ", 5);
                
                crn = Integer.parseInt(cs[1]);
                //change the credits and the crn to integer
                credits = Integer.parseInt(cs[2]);
                
                cde = new CourseDBElement(cs[0], crn, credits, cs[3], cs[4]);
                
                courseDB.add(cde);
               
            }
        } catch (FileNotFoundException e) {
            throw e;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public ArrayList<String> showAll() {
        ArrayList<String> s = new ArrayList<>();
        String t = "[]";
        for (LinkedList<CourseDBElement> bucket : courseDB.hashTable) {
	        for (CourseDBElement cde : bucket) {
	        	if(cde != null && !cde.toString().equals(t)) {
	        		 s.add(cde.toString());
	        	}
	        }
        }
        return s;
    }
    
}
